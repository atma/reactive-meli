import React from 'react';
import Header from './src/Header';

const app = document.createElement('div');
document.body.appendChild(app);

React.render(<Header />, app);
