import React, { Component } from 'react';

let styles = {
    logo: {
        height: '40px',
        top: '7px',
        width: '159px',
        display: 'inline-block',
        background: 'url(https://ui.mlstatic.com/navigation/1.1.2/mercadolibre/logo__large@2x.png) center center no-repeat',
        backgroundSize: '100%',
        margin: '7px 10px'
    }
}

export default class Logo extends Component {

    render() {
        return <a href="/" style={styles.logo} />;
    }

};
