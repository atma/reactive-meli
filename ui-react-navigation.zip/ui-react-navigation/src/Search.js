import React, { Component } from 'react';

let styles = {
    form: {
        display: 'inline-block',
        margin: '7px 10px 7px 40px',
        verticalAlign: 'top',
        maxWidth: '540px',
        position: 'relative'
    },
    input: {
        padding: '5px 60px 5px 15px',
        borderRadius: '3px',
        border: '1px solid #ccc',
        color: '#444',
        fontSize: '16px',
        lineHeight: '30px'
    },
    btn: {
        borderRadius: '0 3px 3px 0',
        width: '46px',
        height: '42px',
        border: '1px solid #ccc',
        backgroundColor: '#fff',
        display: 'inline-block',
        right: '0',
        top: '0',
        position: 'absolute'
    }
};

export default class Search extends Component {

    render() {
        return (
            <form className="nav-search" action="/jm/search" method="GET" role="search" style={styles.form}>
                <input type="text" className="nav-search-input" name="as_word" max-length="120" style={styles.input}/>
                <button type="submit" className="nav-search-btn" style={styles.btn}>
                    <svg height="18px" viewBox="0 0 512 512" width="18px"><path d="M497.913,497.913c-18.782,18.782-49.225,18.782-68.008,0l-84.862-84.863c-34.889,22.382-76.13,35.717-120.659,35.717  C100.469,448.767,0,348.312,0,224.383S100.469,0,224.384,0c123.931,0,224.384,100.452,224.384,224.383  c0,44.514-13.352,85.771-35.718,120.676l84.863,84.863C516.695,448.704,516.695,479.131,497.913,497.913z M224.384,64.109  c-88.511,0-160.274,71.747-160.274,160.273c0,88.526,71.764,160.274,160.274,160.274c88.525,0,160.273-71.748,160.273-160.274  C384.657,135.856,312.909,64.109,224.384,64.109z" fill="#777777"/></svg>
                </button>
            </form>
        )
    }
};


