import React from 'react';
import Logo from './Logo';
import Search from './Search';

let styles = {
    container: {
        backgroundColor: '#fff059',
        color: '#5b562f',
        userSelect: 'none',
        cursor: 'default',
        borderBottom: '1px solid #d9d9d9',
        height: '54px'
    },
    bounds: {
        maxWidth: '1220px'
    }
};

export default class Header extends React.Component {

    componentWillMount() {

    }

    render() {
        return (
            <header className="nav-header" style={styles.container}>
                <div className="nav-bounds">
                    <Logo />
                    <Search />
                </div>
            </header>
        )
    }
}
