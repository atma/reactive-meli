var webpack = require('webpack');
var HtmlwebpackPlugin       = require('html-webpack-plugin');

var path = require('path');
var ejs = require('ejs');
var fs = require('fs');
var autoprefixer = require('autoprefixer');

var ROOT_PATH = path.resolve(__dirname);
var ENV = process.env.NODE_ENV || 'development';

if (ENV === 'production') {
    throw new Error('Use npm build instead');
} else {
    module.exports = {
        entry: './demo.jsx',

        module: {
            loaders: [
                { test: /\.jsx?$/, loaders: ['react-hot', 'babel'], exclude: /node_modules/ },
                { test: /\.css$/, loaders: [
                    'style',
                    'css?modules&importLoaders=1!postcss'
                ] },
                { test: /\.svg$/, loader: "url-loader?limit=10000&mimetype=image/svg+xml" }
            ]
        },

        postcss: [
            autoprefixer({ browsers: [
                'last 5 versions'
            ]})
        ],

        resolve: {
            modulesDirectories: ['node_modules', 'src']
        },

        plugins: [
            new webpack.HotModuleReplacementPlugin(),
            new HtmlwebpackPlugin({
                title: 'UI Navigation'
            })
        ]
    };
}
